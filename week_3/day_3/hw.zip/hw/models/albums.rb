require 'pry'
require '../db/sql_runner'

class Album

  attr_accessor :artist_id, :album_name, :band_name
  attr_reader :id

  def initialize(options)
    @artist_id = options['artist_id'].to_i
    @album_name = options['album_name']
    @band_name = options['band_name']
    @id = options['id'].to_i if options['id']
  end

  def save()
    sql = "INSERT INTO albums ( artist_id, album_name, genre,  )
          VALUES ( $1, $2, $3 ) RETURNING id"
    values = [@album_name]
    customers = SqlRunner.run(sql, values)
    @id = customers [0]["id"].to_i
  end
end
