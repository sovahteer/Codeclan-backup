class Food

attr_reader :name, :price, :rejuvanation_level

def initialize (name, price, rejuvanation_level)
  @name = name
  @price = price
  @rejuvanation_level = rejuvanation_level
end


end
