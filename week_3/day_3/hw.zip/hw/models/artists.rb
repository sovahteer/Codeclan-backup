require 'pry'
require '../db/sql_runner'

class Artist

  attr_accessor :band_name
  attr_reader :id

  def initialize(options)
    @band_name = options['band_name']
    @id = options['id'].to_i if options['id']
  end

  def save()
    sql = "INSERT INTO artists ( band_name ) VALUES ( $1 )
          RETURNING id"
    values = [@band_name]
    artists = SqlRunner.run(sql, values)
    @id = artists [0]["id"].to_i
  end
end
