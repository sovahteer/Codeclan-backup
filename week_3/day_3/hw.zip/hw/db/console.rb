require("pry")
require_relative("../models/albums")
require_relative("../models/artists")

artist1 = Artist.new({'band_name' => 'The Killers'})
artist2 = Artist.new({'band_name' => 'Foo Fighters'})
artist1.save()
artist2.save()

album1 = Album.new({'album_name' => 'Runaways', 'band_name' => 'The Killers'})
album2 = Album.new({'album_name' => 'Concrete and Gold', 'band_name' => 'Foo Fighters'})
album1.save()
album2.save()
