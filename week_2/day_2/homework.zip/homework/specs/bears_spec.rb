require 'Minitest/autorun'
require 'Minitest/rg'
require_relative '../bears.rb'

class TestBear < MiniTest::Test

  def setup()
    @bear = Bear.new("Paddington", "Grizzly")
  end

  def test_bear_name
    assert_equal("Paddington", @bear.name)
  end

  def test_bear_type
    assert_equal("Grizzly",@bear.type)
  end

  def test_count_stomach()
     actual = @bear.count_stomach()
     assert_equal(0, actual)
   end
end
